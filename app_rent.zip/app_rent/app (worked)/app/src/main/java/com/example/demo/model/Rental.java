package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

/**
 * Сущность, представляющая аренду автомобиля в системе.
 */
@Data
@Entity
@Table(name = "rentals")
public class Rental {

    /**
     * Уникальный идентификатор аренды.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Автомобиль, который арендован.
     */
    @ManyToOne
    private Car car;

    /**
     * Клиент, который арендует автомобиль.
     */
    @ManyToOne
    private Client client;

    /**
     * Дата начала аренды.
     */
    @Column(nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;

    /**
     * Дата окончания аренды.
     */
    @Column(nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;

}
