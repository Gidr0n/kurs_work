package com.example.demo.repository;

import com.example.demo.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

/**
 * Репозиторий для работы с сущностью {@link Client}.
 * Предоставляет методы для выполнения операций CRUD и поиска клиентов по различным критериям.
 */
public interface ClientRepository extends JpaRepository<Client, Long> {

    /**
     * Находит клиента по полному имени.
     *
     * @param fullName - полное имя клиента
     * @return объект {@link Optional} с клиентом, если клиент найден, иначе пустой {@link Optional}
     */
    Optional<Client> findByFullName(String fullName);

    /**
     * Находит клиента по логину.
     *
     * @param login - логин клиента
     * @return объект {@link Optional} с клиентом, если клиент найден, иначе пустой {@link Optional}
     */
    Optional<Client> findByLogin(String login);

    /**
     * Проверяет существование клиента по логину.
     *
     * @param login - логин клиента
     * @return true, если клиент с заданным логином существует, иначе false
     */
    boolean existsByLogin(String login);
}
