package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Контроллер для обработки запросов, связанных с информацией об авторе.
 */
@Controller
public class AboutController {

    /**
     * Обрабатывает GET-запрос на URL "/about" и возвращает представление "about".
     *
     * @return имя представления "about"
     */
    @GetMapping("/about")
    public String about() {
        return "about";
    }

    /**
     * Обрабатывает GET-запрос на URL "/atoub" и возвращает представление "atoub".
     *
     * @return имя представления "atoub"
     */
    @GetMapping("/atoub")
    public String atoub() {
        return "atoub";
    }
}
