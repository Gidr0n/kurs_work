package com.example.demo.controller;

import com.example.demo.model.Client;
import com.example.demo.service.CarService;
import com.example.demo.service.ClientService;
import com.example.demo.service.RentalService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

/**
 * Контроллер для обработки запросов, связанных с деятельностью админа в работе с клиентами.
 */
@AllArgsConstructor
@Controller
@RequestMapping("/admin")
public class AdminController {

    private final CarService carService;
    private final ClientService clientService;
    private final RentalService rentalService;


    /**
     * Контроллер для вывода панели тренера
     *
     * @param model - объект типа Model с данными выводимыми на странице
     * @return - выводимая панель тренера
     */
    @GetMapping("/dashboard")
    public String adminDashboard(Model model) {
        List<Client> clients = clientService.getAllClients();
        model.addAttribute("clients", clients);
        return "admin-dashboard";
    }

    /**
     * Отображение формы для добавления нового клиента.
     *
     * @param model - модель, в которую будет добавлен новый объект клиента
     * @return - Шаблона для добавления клиента
     */
    @GetMapping("/add-client")
    public String showAddClientForm(Model model) {
        model.addAttribute("client", new Client());
        return "add-client";
    }

    /**
     * Обрабатывает POST-запрос для добавления нового клиента.
     *
     * @param client объект клиента, который нужно добавить
     * @param model  модель для передачи данных на страницу
     * @return перенаправление на страницу со списком клиентов или возврат на форму добавления с сообщением об ошибке
     */
    @PostMapping("/add-client")
    public String addClient(@ModelAttribute("client") Client client, Model model) {
        try {
            clientService.addClient(client);
            return "redirect:/admin/clients";
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return "add-client";
        }
    }

    /**
     * Обрабатывает GET-запрос для удаления клиента.
     *
     * @param clientId идентификатор клиента, которого нужно удалить
     * @return перенаправление на страницу со списком клиентов
     */
    @GetMapping("/delete-client/{clientId}")
    public String deleteClient(@PathVariable Long clientId) {
        clientService.deleteClient(clientId);
        return "redirect:/admin/clients";
    }

    /**
     * Отображает форму для редактирования клиента.
     *
     * @param clientId идентификатор клиента, которого нужно отредактировать
     * @param model    модель для передачи данных на страницу
     * @return имя представления для редактирования клиента или перенаправление на страницу со списком клиентов
     */
    @GetMapping("/edit-client/{clientId}")
    public String showEditClientForm(@PathVariable Long clientId, Model model) {
        Optional<Client> client = clientService.getClientById(clientId);
        if (client.isPresent()) {
            model.addAttribute("client", client.get());
            return "edit-client";
        } else {
            return "redirect:/admin/clients";
        }
    }

    /**
     * Обрабатывает POST-запрос для обновления данных клиента.
     *
     * @param clientId      идентификатор клиента, которого нужно обновить
     * @param updatedClient объект клиента с обновленными данными
     * @return перенаправление на страницу со списком клиентов
     */
    @PostMapping("/edit-client/{clientId}")
    public String updateClient(@PathVariable Long clientId, @ModelAttribute("client") Client updatedClient) {
        clientService.updateClient(clientId, updatedClient);
        return "redirect:/admin/clients";
    }

    /**
     * Отображает список всех клиентов.
     *
     * @param model модель для передачи данных на страницу
     * @return имя представления со списком клиентов
     */
    @GetMapping("/clients")
    public String viewClients(Model model) {
        List<Client> clients = clientService.getAllClients();
        model.addAttribute("clients", clients);
        return "clients";
    }
}