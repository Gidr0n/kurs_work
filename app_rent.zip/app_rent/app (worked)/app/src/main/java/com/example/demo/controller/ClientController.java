package com.example.demo.controller;

import com.example.demo.model.Car;
import com.example.demo.repository.ClientRepository;
import com.example.demo.service.CarService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.List;

/**
 * Контроллер для работы с клиентами.
 */
@AllArgsConstructor
@Controller
@RequestMapping("/client")
public class ClientController {

    private final CarService carService;
    private ClientRepository clientRepository;

    /**
     * Отображает панель клиента.
     *
     * @param model - модель для передачи данных на страницу
     * @return имя представления панели клиента
     */
    @GetMapping("/dashboard")
    public String clientDashboard(Model model) {
        return "client-dashboard";
    }

    /**
     * Отображает список автомобилей, доступных для клиента.
     *
     * @param clientId - идентификатор клиента
     * @param model - модель для передачи данных на страницу
     * @return имя представления со списком автомобилей
     */
    @GetMapping("/client-cars")
    public String viewClientCars(@RequestParam Long clientId, Model model) {
        List<Car> cars = carService.getAllCars();
        model.addAttribute("cars", cars);
        model.addAttribute("clientId", clientId);
        return "cars";
    }
}
