package com.example.demo.repository;

import com.example.demo.model.Car;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Репозиторий для работы с сущностью {@link Car}.
 * Предоставляет методы для выполнения операций CRUD и поиска автомобилей по различным критериям.
 */
public interface CarRepository extends JpaRepository<Car, Long> {

    /**
     * Находит автомобили по марке.
     *
     * @param make - марка автомобиля
     * @return список автомобилей, соответствующих заданной марке
     */
    List<Car> findByMake(String make);

    /**
     * Находит автомобили по модели.
     *
     * @param model - модель автомобиля
     * @return список автомобилей, соответствующих заданной модели
     */
    List<Car> findByModel(String model);

    /**
     * Находит автомобили по статусу аренды.
     *
     * @param rented - статус аренды автомобиля (например, "rented" или "available")
     * @return список автомобилей, соответствующих заданному статусу аренды
     */
    List<Car> findByRented(String rented);

    /**
     * Проверяет существование автомобиля по номерному знаку.
     *
     * @param licensePlate - номерной знак автомобиля
     * @return true, если автомобиль с заданным номерным знаком существует, иначе false
     */
    boolean existsByLicensePlate(String licensePlate);

    /**
     * Находит все автомобили, отсортированные по марке в порядке возрастания.
     *
     * @return список автомобилей, отсортированных по марке
     */
    List<Car> findAllByOrderByMakeAsc();

    /**
     * Находит все автомобили, отсортированные по модели в порядке возрастания.
     *
     * @return список автомобилей, отсортированных по модели
     */
    List<Car> findAllByOrderByModelAsc();
}
