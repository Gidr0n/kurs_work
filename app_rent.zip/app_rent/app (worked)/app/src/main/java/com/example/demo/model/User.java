package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;

/**
 * Абстрактный класс, представляющий пользователя в системе.
 * Этот класс содержит общие поля для всех типов пользователей.
 */
@Data
@MappedSuperclass
public abstract class User {

    /**
     * Уникальный идентификатор пользователя.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Полное имя пользователя.
     */
    @Column(nullable = false)
    private String fullName;

    /**
     * Логин пользователя. Должен быть уникальным.
     */
    @Column(nullable = false, unique = true)
    private String login;

    /**
     * Пароль пользователя.
     */
    @Column(nullable = false)
    private String password;

    /**
     * Дата рождения пользователя.
     */
    @Column(nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate birthdate;

    /**
     * Номер телефона пользователя.
     */
    @Column(nullable = false)
    private String phoneNumber;

    /**
     * Роль пользователя (например, "Клиент" или "Админ").
     */
    @Column(nullable = false)
    private String role;
}
