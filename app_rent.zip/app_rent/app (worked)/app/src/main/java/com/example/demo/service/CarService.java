package com.example.demo.service;

import com.example.demo.model.Car;
import com.example.demo.repository.CarRepository;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Сервис для управления автомобилями.
 */
@AllArgsConstructor
@Service
public class CarService {

    private static final Logger logger = LoggerFactory.getLogger(CarService.class);
    private final CarRepository carRepository;

    /**
     * Добавляет новый автомобиль.
     *
     * @param car - объект типа {@link Car}, содержащий данные нового автомобиля
     * @throws IllegalArgumentException если номерной знак уже существует или данные автомобиля некорректны
     */
    public void addCar(Car car) {
        logger.info("Попытка добавления нового автомобиля: {}", car);
        validateCar(car);
        if (carRepository.existsByLicensePlate(car.getLicensePlate())) {
            logger.error("Номерной знак уже существует: {}", car.getLicensePlate());
            throw new IllegalArgumentException("Номерной знак уже существует");
        }
        logger.info("Сохранение автомобиля: {}", car);
        carRepository.save(car);
    }

    /**
     * Обновляет данные автомобиля по идентификатору.
     *
     * @param carId - идентификатор автомобиля
     * @param updatedCar - объект типа {@link Car}, содержащий обновленные данные автомобиля
     * @throws IllegalArgumentException если автомобиль не найден, номерной знак уже существует или данные автомобиля некорректны
     */
    public void updateCar(Long carId, Car updatedCar) {
        logger.info("Попытка обновления автомобиля с id: {}", carId);
        validateCar(updatedCar);
        Optional<Car> existingCar = carRepository.findById(carId);
        if (existingCar.isPresent()) {
            Car car = existingCar.get();
            car.setMake(updatedCar.getMake());
            car.setModel(updatedCar.getModel());
            if (!car.getLicensePlate().equals(updatedCar.getLicensePlate())) {
                if (carRepository.existsByLicensePlate(updatedCar.getLicensePlate())) {
                    logger.error("Номерной знак уже существует: {}", updatedCar.getLicensePlate());
                    throw new IllegalArgumentException("Номерной знак уже существует");
                }
                if (!isValidLicensePlate(updatedCar.getLicensePlate())) {
                    logger.error("Неверный формат номерного знака: {}", updatedCar.getLicensePlate());
                    throw new IllegalArgumentException("Неверный формат номерного знака. Пожалуйста, используйте формат LNNNLLNNN, где L - буква, а N - цифра.");
                }
                car.setLicensePlate(updatedCar.getLicensePlate());
            }
            car.setPricePerDay(updatedCar.getPricePerDay());
            car.setRented(updatedCar.getRented());
            logger.info("Обновление автомобиля: {}", car);
            carRepository.save(car);
        } else {
            logger.error("Автомобиль не найден с id: {}", carId);
            throw new IllegalArgumentException("Автомобиль не найден с id: " + carId);
        }
    }

    /**
     * Удаляет автомобиль по идентификатору.
     *
     * @param carId - идентификатор автомобиля
     * @throws IllegalArgumentException если автомобиль не найден
     */
    public void deleteCar(Long carId) {
        logger.info("Попытка удаления автомобиля с id: {}", carId);
        if (!carRepository.existsById(carId)) {
            logger.error("Автомобиль не найден с id: {}", carId);
            throw new IllegalArgumentException("Автомобиль не найден с id: " + carId);
        }
        carRepository.deleteById(carId);
        logger.info("Автомобиль с id: {} успешно удален", carId);
    }

    /**
     * Получает список всех автомобилей.
     *
     * @return список всех автомобилей
     */
    public List<Car> getAllCars() {
        logger.info("Получение всех автомобилей");
        return carRepository.findAll();
    }

    /**
     * Получает автомобиль по идентификатору.
     *
     * @param carId - идентификатор автомобиля
     * @return объект {@link Optional} с автомобилем, если автомобиль найден, иначе пустой {@link Optional}
     */
    public Optional<Car> getCarById(Long carId) {
        logger.info("Получение автомобиля с id: {}", carId);
        return carRepository.findById(carId);
    }

    /**
     * Находит автомобили по статусу аренды.
     *
     * @param rented - статус аренды автомобиля (например, "Арендован" или "Не арендован")
     * @return список автомобилей, соответствующих заданному статусу аренды
     */
    public List<Car> findByRented(String rented) {
        logger.info("Получение автомобилей со статусом аренды: {}", rented);
        return carRepository.findByRented(rented);
    }

    /**
     * Проверяет корректность формата номерного знака.
     *
     * @param licensePlate - номерной знак автомобиля
     * @return true, если формат номерного знака корректен, иначе false
     */
    private boolean isValidLicensePlate(String licensePlate) {
        return licensePlate.matches("^[АВЕКМНОРСТУХ]{1}[0-9]{3}[АВЕКМНОРСТУХ]{2}[0-9]{2,3}$");
    }

    /**
     * Валидирует данные автомобиля.
     *
     * @param car - объект типа {@link Car}, содержащий данные автомобиля
     * @throws IllegalArgumentException если данные автомобиля некорректны
     */
    private void validateCar(Car car) {
        if (car.getMake() == null || car.getMake().isEmpty()) {
            logger.error("Марка автомобиля не может быть пустой");
            throw new IllegalArgumentException("Марка автомобиля не может быть пустой");
        }
        if (car.getModel() == null || car.getModel().isEmpty()) {
            logger.error("Модель автомобиля не может быть пустой");
            throw new IllegalArgumentException("Модель автомобиля не может быть пустой");
        }
        if (car.getLicensePlate() == null || car.getLicensePlate().isEmpty()) {
            logger.error("Номерной знак не может быть пустым");
            throw new IllegalArgumentException("Номерной знак не может быть пустым");
        }
        if (car.getPricePerDay() <= 0) {
            logger.error("Цена аренды в день должна быть положительной");
            throw new IllegalArgumentException("Цена аренды в день должна быть положительной");
        }
        if (car.getRented() == null || !(car.getRented().equals("Арендован") || car.getRented().equals("Не арендован"))) {
            logger.error("Состояние аренды должно быть 'Арендован' или 'Не арендован'");
            throw new IllegalArgumentException("Состояние аренды должно быть 'Арендован' или 'Не арендован'");
        }
    }
}
