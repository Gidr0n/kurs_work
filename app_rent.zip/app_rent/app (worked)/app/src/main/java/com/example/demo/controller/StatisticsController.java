package com.example.demo.controller;

import com.example.demo.model.Rental;
import com.example.demo.repository.RentalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * Контроллер для обработки запросов, связанных со статистическими данными.
 */
@Controller
public class StatisticsController {

    @Autowired
    private RentalRepository rentalRepository;

    /**
     * Отображает страницу со статистическими данными.
     *
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения статистики
     */
    @GetMapping("/admin/statistics")
    public String statistics(Model model) {
        List<Rental> rentals = rentalRepository.findAll();

        double averagePrice = rentals.stream()
                .mapToDouble(rental -> rental.getCar().getPricePerDay())
                .average()
                .orElse(0);

        double maxPrice = rentals.stream()
                .mapToDouble(rental -> rental.getCar().getPricePerDay())
                .max()
                .orElse(0);

        double minPrice = rentals.stream()
                .mapToDouble(rental -> rental.getCar().getPricePerDay())
                .min()
                .orElse(0);

        double averageDays = rentals.stream()
                .mapToLong(rental -> rental.getEndDate().toEpochDay() - rental.getStartDate().toEpochDay())
                .average()
                .orElse(0);

        long maxDays = rentals.stream()
                .mapToLong(rental -> rental.getEndDate().toEpochDay() - rental.getStartDate().toEpochDay())
                .max()
                .orElse(0);

        long minDays = rentals.stream()
                .mapToLong(rental -> rental.getEndDate().toEpochDay() - rental.getStartDate().toEpochDay())
                .min()
                .orElse(0);

        model.addAttribute("averagePrice", averagePrice);
        model.addAttribute("maxPrice", maxPrice);
        model.addAttribute("minPrice", minPrice);
        model.addAttribute("averageDays", averageDays);
        model.addAttribute("maxDays", maxDays);
        model.addAttribute("minDays", minDays);

        return "statistics";
    }
}
