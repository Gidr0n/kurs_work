package com.example.demo.controller;

import com.example.demo.model.Car;
import com.example.demo.service.CarService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

/**
 * Контроллер для управления автомобилями.
 */
@AllArgsConstructor
@Controller
@RequestMapping("/admin")
public class CarController {

    private final CarService carService;

    /**
     * Отображает форму для добавления нового автомобиля.
     *
     * @param model модель для передачи данных на страницу
     * @return имя представления для добавления автомобиля
     */
    @GetMapping("/add-car")
    public String showAddCarForm(Model model) {
        model.addAttribute("car", new Car());
        return "add-car";
    }

    /**
     * Обрабатывает POST-запрос для добавления нового автомобиля.
     *
     * @param car - объект автомобиля, который нужно добавить
     * @param bindingResult - результат валидации
     * @param model - модель для передачи данных на страницу
     * @return перенаправление на страницу со списком автомобилей или возврат на форму добавления с сообщением об ошибке
     */
    @PostMapping("/add-car")
    public String addCar(@ModelAttribute("car") Car car, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "add-car";
        }
        try {
            carService.addCar(car);
            return "redirect:/admin/cars";
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return "add-car";
        }
    }

    /**
     * Обрабатывает GET-запрос для удаления автомобиля.
     *
     * @param carId - идентификатор автомобиля, который нужно удалить
     * @return перенаправление на страницу со списком автомобилей
     */
    @GetMapping("/delete-car/{carId}")
    public String deleteCar(@PathVariable Long carId) {
        try {
            carService.deleteCar(carId);
        } catch (IllegalArgumentException e) {
        }
        return "redirect:/admin/cars";
    }

    /**
     * Отображает форму для редактирования автомобиля.
     *
     * @param carId - идентификатор автомобиля, который нужно отредактировать
     * @param model - модель для передачи данных на страницу
     * @return имя представления для редактирования автомобиля или перенаправление на страницу со списком автомобилей
     */
    @GetMapping("/edit-car/{carId}")
    public String showEditCarForm(@PathVariable Long carId, Model model) {
        Optional<Car> car = carService.getCarById(carId);
        if (car.isPresent()) {
            model.addAttribute("car", car.get());
            return "edit-car";
        } else {
            return "redirect:/admin/cars";
        }
    }

    /**
     * Обрабатывает POST-запрос для обновления данных автомобиля.
     *
     * @param carId - идентификатор автомобиля, который нужно обновить
     * @param updatedCar - объект автомобиля с обновленными данными
     * @param bindingResult - результат валидации
     * @param model - модель для передачи данных на страницу
     * @return перенаправление на страницу со списком автомобилей или возврат на форму редактирования с сообщением об ошибке
     */
    @PostMapping("/edit-car/{carId}")
    public String updateCar(@PathVariable Long carId, @ModelAttribute("car") Car updatedCar, BindingResult bindingResult, Model model) {
        if (bindingResult.hasErrors()) {
            return "edit-car";
        }
        try {
            carService.updateCar(carId, updatedCar);
            return "redirect:/admin/cars";
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            model.addAttribute("car", updatedCar);
            return "edit-car";
        }
    }

    /**
     * Отображает список всех автомобилей.
     *
     * @param model - модель для передачи данных на страницу
     * @return имя представления со списком автомобилей
     */
    @GetMapping("/cars")
    public String viewCars(Model model) {
        List<Car> cars = carService.getAllCars();
        model.addAttribute("cars", cars);
        return "cars";
    }
}
