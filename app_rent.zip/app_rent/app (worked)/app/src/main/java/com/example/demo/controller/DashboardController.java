package com.example.demo.controller;

import com.example.demo.model.Client;
import com.example.demo.service.ClientService;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import java.io.IOException;
import java.util.List;

/**
 * Контроллер для обработки запросов, связанных с меню пользователя и админа.
 */
@Controller
public class DashboardController {

    private final ClientService clientService;

    public DashboardController(ClientService clientService) {
        this.clientService = clientService;
    }

    /**
     * Перенаправляет пользователя на соответствующую панель управления в зависимости от его роли.
     * @param authentication - объект аутентификации, содержащий информацию о текущем пользователе
     * @param response - объект для отправки HTTP-ответов
     * @throws IOException - исключение, выбрасываемое при ошибке перенаправления
     */
    @GetMapping("/dashboard")
    public void redirectDashboard(Authentication authentication, HttpServletResponse response) throws IOException {
        if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_CLIENT"))) {
            response.sendRedirect("/dashboard/client");
        } else if (authentication.getAuthorities().contains(new SimpleGrantedAuthority("ROLE_ADMIN"))) {
            response.sendRedirect("/dashboard/admin");
        } else {
            response.sendRedirect("/");
        }
    }
    /**
     * Отображает панель управления для тренера, включая список всех клиентов.
     * @param model - носитель типа Model, для передачи данных в представление
     * @return - имя шаблона, отображающего панель управления тренера
     */
    @GetMapping("/admin/dashboard/")
    public String adminDashboard(Model model) {
        List<Client> clients =  clientService.getAllClients();
        model.addAttribute("admin", clients);
        return "admin-dashboard";
    }

}
