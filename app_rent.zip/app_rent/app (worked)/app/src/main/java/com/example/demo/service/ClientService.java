package com.example.demo.service;

import com.example.demo.model.Client;
import com.example.demo.repository.ClientRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Сервис для управления клиентами.
 */
@AllArgsConstructor
@Service
public class ClientService {

    private final ClientRepository clientRepository;
    private final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    /**
     * Добавляет нового клиента в базу данных.
     *
     * @param client - объект типа {@link Client}, содержащий информацию о новом клиенте
     * @return добавленный клиент
     * @throws IllegalArgumentException если логин уже существует
     */
    public Client addClient(Client client) {
        if (clientRepository.existsByLogin(client.getLogin())) {
            throw new IllegalArgumentException("Логин уже существует");
        }
        client.setPassword(passwordEncoder.encode(client.getPassword()));
        return clientRepository.save(client);
    }

    /**
     * Обновляет данные клиента.
     *
     * @param clientId - идентификатор клиента
     * @param updatedClient - объект типа {@link Client}, содержащий обновленные данные клиента
     * @return обновленный клиент
     * @throws IllegalArgumentException если клиент не найден
     */
    public Client updateClient(Long clientId, Client updatedClient) {
        Optional<Client> existingClient = clientRepository.findById(clientId);
        if (existingClient.isPresent()) {
            Client client = existingClient.get();
            client.setFullName(updatedClient.getFullName());
            client.setBirthdate(updatedClient.getBirthdate());
            client.setPhoneNumber(updatedClient.getPhoneNumber());
            client.setLogin(client.getLogin());
            if (!updatedClient.getPassword().isEmpty()) {
                client.setPassword(passwordEncoder.encode(updatedClient.getPassword()));
            }
            client.setRole(updatedClient.getRole());
            return clientRepository.save(client);
        } else {
            throw new IllegalArgumentException("Клиент не найден с id: " + clientId);
        }
    }

    /**
     * Удаляет клиента по идентификатору.
     *
     * @param clientId - идентификатор клиента
     */
    public void deleteClient(Long clientId) {
        clientRepository.deleteById(clientId);
    }

    /**
     * Находит клиента по полному имени.
     *
     * @param fullName - полное имя клиента
     * @return объект {@link Optional} с клиентом, если клиент найден, иначе пустой {@link Optional}
     */
    public Optional<Client> findByFullName(String fullName) {
        return clientRepository.findByFullName(fullName);
    }

    /**
     * Получает список всех клиентов.
     *
     * @return список всех клиентов
     */
    public List<Client> getAllClients() {
        return clientRepository.findAll();
    }

    /**
     * Получает клиента по идентификатору.
     *
     * @param clientId - идентификатор клиента
     * @return объект {@link Optional} с клиентом, если клиент найден, иначе пустой {@link Optional}
     */
    public Optional<Client> getClientById(Long clientId) {
        return clientRepository.findById(clientId);
    }

    /**
     * Сохраняет клиента в базу данных.
     *
     * @param client - объект типа {@link Client}, который нужно сохранить
     */
    public void saveClient(Client client) {
        clientRepository.save(client);
    }

    /**
     * Аутентифицирует клиента по логину и паролю.
     *
     * @param login - логин клиента
     * @param password - пароль клиента
     * @return объект {@link Optional} с клиентом, если аутентификация успешна, иначе пустой {@link Optional}
     */
    public Optional<Client> authenticate(String login, String password) {
        Optional<Client> clientOptional = clientRepository.findByLogin(login);
        if (clientOptional.isPresent()) {
            Client client = clientOptional.get();
            if (passwordEncoder.matches(password, client.getPassword())) {
                return Optional.of(client);
            }
        }
        return Optional.empty();
    }
}
