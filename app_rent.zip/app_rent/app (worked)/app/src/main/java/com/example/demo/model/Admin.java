package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

/**
 * Сущность, представляющая администратора в системе.
 * Наследует базовые поля и методы от класса {@link User}.
 */
@Data
@Entity
@Table(name = "admins")
public class Admin extends User {
}
