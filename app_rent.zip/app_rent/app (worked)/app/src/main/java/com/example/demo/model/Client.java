package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Сущность, представляющая клиента в системе.
 * Наследует базовые поля и методы от класса {@link User}.
 */
@Data
@Entity
@Table(name = "clients")
public class Client extends User {

}
