package com.example.demo.service;

import com.example.demo.model.Client;
import com.example.demo.repository.AdminRepository;
import com.example.demo.repository.ClientRepository;


import java.util.Optional;

public class AdminService {

    private final AdminRepository adminRepository;
    private final ClientRepository clientRepository;

        public AdminService(AdminRepository adminRepository, ClientRepository clientRepository) {
        this.adminRepository = adminRepository;
        this.clientRepository = clientRepository;
        }


    /**
     * Метод поиска имеющегося в базе клиента по id
     *
     * @param id - id искомого клиента
     * @return - клиент с соответствующим id
     */
    public Client getClientById(Long id) {
        Optional<Client> clientOptional = clientRepository.findById(id);
        return clientOptional.orElseThrow(() -> new IllegalArgumentException("Client not found with id: " + id));
    }
}
