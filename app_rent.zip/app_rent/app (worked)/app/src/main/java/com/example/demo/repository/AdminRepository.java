package com.example.demo.repository;

import com.example.demo.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Репозиторий для работы с сущностью {@link Admin}.
 * Предоставляет методы для выполнения операций CRUD и поиска администраторов по логину.
 */
public interface AdminRepository extends JpaRepository<Admin, Long> {

}
