package com.example.demo.controller;

import com.example.demo.model.Client;
import com.example.demo.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Контроллер для обработки запросов, связанных с регистрацией.
 */
@Controller
public class RegistrationController {

    @Autowired
    private ClientRepository clientRepository;

    /**
     * Отображает форму регистрации.
     *
     * @param returnUrl - URL для возврата после успешной регистрации
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения формы регистрации
     */
    @GetMapping("/register")
    public String showRegistrationForm(@RequestParam(required = false) String returnUrl, Model model) {
        model.addAttribute("returnUrl", returnUrl);
        return "register";
    }

    /**
     * Обрабатывает данные формы регистрации.
     *
     * @param returnUrl - URL для возврата после успешной регистрации
     * @param client - объект типа {@link Client}, содержащий данные нового клиента
     * @param model - модель для передачи данных в представление
     * @return перенаправление на страницу после успешной регистрации или отображение формы регистрации с сообщением об ошибке
     */
    @PostMapping("/register")
    public String processRegistration(@RequestParam(required = false) String returnUrl, Client client, Model model) {
        if (clientRepository.existsByLogin(client.getLogin())) {
            model.addAttribute("errorMessage", "Логин уже занят. Пожалуйста, выберите другой логин.");
            model.addAttribute("returnUrl", returnUrl);
            return "register";
        }

        client.setRole("Клиент");

        clientRepository.save(client);

        if (returnUrl != null && !returnUrl.isEmpty()) {
            return "redirect:" + returnUrl;
        } else {
            return "redirect:/client/dashboard";
        }
    }
}
