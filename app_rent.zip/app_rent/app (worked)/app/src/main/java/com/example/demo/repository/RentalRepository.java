package com.example.demo.repository;

import com.example.demo.model.Rental;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Репозиторий для работы с сущностью {@link Rental}.
 * Предоставляет методы для выполнения операций CRUD и поиска арендованных автомобилей по различным критериям.
 */
@Repository
public interface RentalRepository extends JpaRepository<Rental, Long> {

    /**
     * Находит аренды по идентификатору автомобиля и дате окончания аренды.
     *
     * @param carId - идентификатор автомобиля
     * @param endDate - дата окончания аренды
     * @return список арендованных автомобилей, соответствующих заданному идентификатору автомобиля и дате окончания аренды
     */
    List<Rental> findByCarIdAndEndDateAfter(Long carId, LocalDate endDate);

    /**
     * Находит все аренды, отсортированные по дате начала аренды в порядке возрастания.
     *
     * @return список арендованных автомобилей, отсортированных по дате начала аренды
     */
    List<Rental> findAllByOrderByStartDateAsc();

    /**
     * Находит все аренды, отсортированные по дате окончания аренды в порядке возрастания.
     *
     * @return список арендованных автомобилей, отсортированных по дате окончания аренды
     */
    List<Rental> findAllByOrderByEndDateAsc();
}
