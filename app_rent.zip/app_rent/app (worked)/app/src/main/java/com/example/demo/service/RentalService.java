package com.example.demo.service;

import com.example.demo.model.Rental;
import com.example.demo.repository.RentalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Сервис для управления арендами автомобилей.
 */
@Service
public class RentalService {

    @Autowired
    private RentalRepository rentalRepository;

    /**
     * Получает список всех арендованных автомобилей.
     *
     * @return список всех арендованных автомобилей
     */
    public List<Rental> getAllRentals() {
        return rentalRepository.findAll();
    }

    /**
     * Получает арендованный автомобиль по идентификатору.
     *
     * @param id - идентификатор арендованного автомобиля
     * @return объект {@link Optional} с арендованным автомобилем, если автомобиль найден, иначе пустой {@link Optional}
     */
    public Optional<Rental> getRentalById(Long id) {
        return rentalRepository.findById(id);
    }

    /**
     * Обновляет данные арендованного автомобиля.
     *
     * @param id - идентификатор арендованного автомобиля
     * @param rental - объект типа {@link Rental}, содержащий обновленные данные арендованного автомобиля
     */
    public void updateRental(Long id, Rental rental) {
        rental.setId(id);
        rentalRepository.save(rental);
    }

    /**
     * Удаляет арендованный автомобиль по идентификатору.
     *
     * @param id - идентификатор арендованного автомобиля
     */
    public void deleteRental(Long id) {
        rentalRepository.deleteById(id);
    }

    /**
     * Сохраняет даты аренды автомобиля.
     *
     * @param rental - объект типа {@link Rental}, содержащий даты аренды автомобиля
     */
    public void saveRentalDates(Rental rental) {
        rentalRepository.save(rental);
    }

    /**
     * Создает новую аренду.
     *
     * @param rental - объект типа {@link Rental}, содержащий данные новой аренды
     */
    public void createRental(Rental rental) {
        rentalRepository.save(rental);
    }

    /**
     * Проверяет доступность автомобиля для аренды.
     *
     * @param carId - идентификатор автомобиля
     * @return true, если автомобиль доступен для аренды, иначе false
     */
    public boolean isCarAvailable(Long carId) {
        return rentalRepository.findByCarIdAndEndDateAfter(carId, LocalDate.now()).isEmpty();
    }

    /**
     * Получает список всех арендованных автомобилей, отсортированных по дате начала аренды в порядке возрастания.
     *
     * @return список арендованных автомобилей, отсортированных по дате начала аренды
     */
    public List<Rental> getAllRentalsSortedByStartDate() {
        return rentalRepository.findAllByOrderByStartDateAsc();
    }

    /**
     * Получает список всех арендованных автомобилей, отсортированных по дате окончания аренды в порядке возрастания.
     *
     * @return список арендованных автомобилей, отсортированных по дате окончания аренды
     */
    public List<Rental> getAllRentalsSortedByEndDate() {
        return rentalRepository.findAllByOrderByEndDateAsc();
    }
}
