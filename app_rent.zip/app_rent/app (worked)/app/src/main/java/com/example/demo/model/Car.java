package com.example.demo.model;

import jakarta.persistence.*;
import lombok.Data;

/**
 * Сущность, представляющая автомобиль в системе.
 */
@Data
@Entity
@Table(name = "cars")
public class Car {

    /**
     * Уникальный идентификатор автомобиля.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Марка автомобиля.
     */
    @Column(nullable = false)
    private String make;

    /**
     * Модель автомобиля.
     */
    @Column(nullable = false)
    private String model;

    /**
     * Номерной знак автомобиля.
     */
    @Column(nullable = false)
    private String licensePlate;

    /**
     * Цена аренды автомобиля в день.
     */
    @Column(nullable = false)
    private double pricePerDay;

    /**
     * Статус аренды автомобиля (арендован ли автомобиль).
     */
    @Column(nullable = false)
    private String rented;
}
