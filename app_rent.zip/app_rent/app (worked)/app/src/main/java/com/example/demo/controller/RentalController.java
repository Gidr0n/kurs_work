package com.example.demo.controller;

import com.example.demo.model.Car;
import com.example.demo.model.Client;
import com.example.demo.model.Rental;
import com.example.demo.repository.CarRepository;
import com.example.demo.repository.ClientRepository;
import com.example.demo.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Контроллер для обработки запросов, связанных с процессом аренды автомобиля.
 */
@Controller
public class RentalController {

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private RentalService rentalService;

    /**
     * Отображает список доступных для аренды автомобилей.
     *
     * @param sort - параметр сортировки (по марке или модели)
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения списка автомобилей
     */
    @GetMapping("/rent")
    public String index(@RequestParam(required = false) String sort, Model model) {
        List<Car> availableCars;
        if ("make".equals(sort)) {
            availableCars = carRepository.findAllByOrderByMakeAsc();
        } else if ("model".equals(sort)) {
            availableCars = carRepository.findAllByOrderByModelAsc();
        } else {
            availableCars = carRepository.findByRented("Не арендован");
        }
        model.addAttribute("cars", availableCars);
        return "rent-car";
    }

    /**
     * Перенаправляет на форму аренды для выбранного автомобиля.
     *
     * @param id - идентификатор автомобиля
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения формы аренды или перенаправление на список автомобилей
     */
    @GetMapping("/rent/{id}")
    public String redirectToRentForm(@PathVariable Long id, Model model) {
        Car car = carRepository.findById(id).orElse(null);
        if (car != null && "Не арендован".equals(car.getRented())) {
            model.addAttribute("carId", car.getId());
            return "rent-form";
        }
        return "redirect:/rent";
    }

    /**
     * Обрабатывает подтверждение аренды автомобиля.
     *
     * @param carId - идентификатор автомобиля
     * @param login - логин клиента
     * @param password - пароль клиента
     * @param startDate - дата начала аренды
     * @param endDate - дата окончания аренды
     * @param model - модель для передачи данных в представление
     * @return перенаправление на страницу подтверждения аренды или отображение формы аренды с сообщением об ошибке
     */
    @PostMapping("/rent/confirm")
    public String confirmRental(@RequestParam Long carId, @RequestParam String login, @RequestParam String password, @RequestParam LocalDate startDate, @RequestParam LocalDate endDate, Model model) {
        Optional<Client> clientOptional = clientRepository.findByLogin(login);
        if (clientOptional.isEmpty()) {
            model.addAttribute("errorMessage", "Клиент с таким логином не найден.");
            model.addAttribute("carId", carId);
            return "rent-form";
        }

        Client client = clientOptional.get();

        if (!client.getPassword().equals(password)) {
            model.addAttribute("errorMessage", "Неверный пароль.");
            model.addAttribute("carId", carId);
            return "rent-form";
        }

        Car car = carRepository.findById(carId).orElse(null);
        if (car == null || !"Не арендован".equals(car.getRented())) {
            model.addAttribute("errorMessage", "Автомобиль недоступен для аренды.");
            model.addAttribute("carId", carId);
            return "rent-form";
        }

        Rental rental = new Rental();
        rental.setCar(car);
        rental.setClient(client);
        rental.setStartDate(startDate);
        rental.setEndDate(endDate);

        rentalService.createRental(rental);
        car.setRented("Арендован");
        carRepository.save(car);

        return "redirect:/rent/confirm";
    }

    /**
     * Отображает страницу подтверждения аренды.
     *
     * @return имя представления для отображения страницы подтверждения аренды
     */
    @GetMapping("/rent/confirm")
    public String showConfirmation() {
        return "rent-confirmation";
    }

    /**
     * Отображает список всех аренд.
     *
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения списка аренд
     */
    @GetMapping("/rentals")
    public String viewRentals(Model model) {
        List<Rental> rentals = rentalService.getAllRentals();
        model.addAttribute("rentals", rentals);
        return "rentals";
    }

    /**
     * Отображает результаты поиска автомобилей по марке, модели или статусу аренды.
     *
     * @param make - марка автомобиля
     * @param model - модель автомобиля
     * @param rented - статус аренды автомобиля
     * @param searchModel - модель для передачи данных в представление
     * @return имя представления для отображения результатов поиска
     */
    @GetMapping("/search")
    public String searchCars(@RequestParam(required = false) String make, @RequestParam(required = false) String model, @RequestParam(required = false) String rented, Model searchModel) {
        List<Car> cars;
        if (make != null) {
            cars = carRepository.findByMake(make);
        } else if (model != null) {
            cars = carRepository.findByModel(model);
        } else if (rented != null) {
            cars = carRepository.findByRented(rented);
        } else {
            cars = carRepository.findByRented("Арендован");
        }
        searchModel.addAttribute("cars", cars);
        return "rent-car";
    }
}
