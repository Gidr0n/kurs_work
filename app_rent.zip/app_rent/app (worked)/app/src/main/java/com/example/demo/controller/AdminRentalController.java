package com.example.demo.controller;

import com.example.demo.model.Car;
import com.example.demo.model.Rental;
import com.example.demo.repository.CarRepository;
import com.example.demo.service.RentalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

/**
 * Контроллер для обработки запросов, связанных с деятельностью админа в работе с арендами.
 */
@Controller
public class AdminRentalController {

    @Autowired
    private RentalService rentalService;

    @Autowired
    private CarRepository carRepository;

    /**
     * Отображает список всех аренд.
     *
     * @param model модель для передачи данных в представление
     * @return имя представления для отображения списка аренд
     */
    @GetMapping("/admin/rentals")
    public String viewRentals(Model model) {
        List<Rental> rentals = rentalService.getAllRentals();
        model.addAttribute("rentals", rentals);
        return "admin-rentals";
    }

    /**
     * Отображает список всех аренд, отсортированных по дате начала аренды.
     *
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения списка аренд
     */
    @GetMapping("/admin/rentals/sortByStartDate")
    public String sortRentalsByStartDate(Model model) {
        List<Rental> rentals = rentalService.getAllRentalsSortedByStartDate();
        model.addAttribute("rentals", rentals);
        return "admin-rentals";
    }

    /**
     * Отображает список всех аренд, отсортированных по дате окончания аренды.
     *
     * @param model - модель для передачи данных в представление
     * @return имя представления для отображения списка аренд
     */
    @GetMapping("/admin/rentals/sortByEndDate")
    public String sortRentalsByEndDate(Model model) {
        List<Rental> rentals = rentalService.getAllRentalsSortedByEndDate();
        model.addAttribute("rentals", rentals);
        return "admin-rentals";
    }

    /**
     * Удаляет аренду по идентификатору и освобождает автомобиль.
     *
     * @param id - идентификатор аренды
     * @return перенаправление на страницу со списком аренд
     */
    @GetMapping("/admin/rentals/delete/{id}")
    public String deleteRental(@PathVariable Long id) {
        Rental rental = rentalService.getRentalById(id).orElse(null);
        if (rental != null) {
            Car car = rental.getCar();
            car.setRented("Не арендован");
            carRepository.save(car);
            rentalService.deleteRental(id);
        }
        return "redirect:/admin/rentals";
    }
}
