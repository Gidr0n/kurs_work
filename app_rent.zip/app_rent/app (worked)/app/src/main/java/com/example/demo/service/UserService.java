package com.example.demo.service;

import com.example.demo.model.Client;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Сервис для управления пользователями.
 */
@Service
public class UserService {

    private final UserRepository clientRepository;

    /**
     * Конструктор для инициализации сервиса.
     *
     * @param clientRepository репозиторий для работы с пользователями
     */
    @Autowired
    public UserService(UserRepository clientRepository) {
        this.clientRepository = clientRepository;
    }

    /**
     * Создает нового клиента.
     *
     * @param client - объект типа {@link Client}, содержащий информацию о новом клиенте
     */
    public void createClient(Client client) {
        clientRepository.save(client);
    }
}
