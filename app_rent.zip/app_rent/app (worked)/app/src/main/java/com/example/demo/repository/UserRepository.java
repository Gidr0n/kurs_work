package com.example.demo.repository;

import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Репозиторий для работы с сущностью {@link User}.
 * Предоставляет методы для выполнения операций CRUD с пользователями.
 */
public interface UserRepository extends JpaRepository<User, Long> {
}
